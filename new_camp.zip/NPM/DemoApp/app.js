var something = require("cat-me");
var joke = require("knock-knock-jokes");

console.log(something());
console.log(joke());